#!/usr/bin/env python3
"""Relatorio final da AEP Grupo Gaia em DOCX (versao 2)."""
from pathlib import Path
from docx import Document
from docx.shared import Inches, Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_LINE_SPACING, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE=Path(__file__).resolve().parent.parent
OUT=BASE/'documentacao'/'Relatorio_Final_Grupo_Gaia_AEP2.docx'
NAVY='143C5B'; BLUE='245F88'; LIGHT='DCEAF5'; GRAY='5D6C76'

doc=Document()
sec=doc.sections[0]
sec.page_height=Cm(29.7); sec.page_width=Cm(21)
sec.left_margin=Cm(3); sec.top_margin=Cm(2.6)
sec.right_margin=Cm(2); sec.bottom_margin=Cm(2)
sec.header_distance=Cm(1.2); sec.footer_distance=Cm(1.1)
styles=doc.styles
normal=styles['Normal']; normal.font.name='Times New Roman'; normal.font.size=Pt(11)
normal.font.color.rgb=RGBColor(32,42,50)
normal.paragraph_format.line_spacing=1.4
normal.paragraph_format.space_after=Pt(7)
normal.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY
for name,size,before,after in [('Title',21,0,20),('Heading 1',15,18,9),('Heading 2',12.5,12,6),('Heading 3',11.2,9,5)]:
    st=styles[name]; st.font.name='Arial'; st.font.size=Pt(size); st.font.bold=True; st.font.color.rgb=RGBColor.from_string(NAVY)
    st.paragraph_format.space_before=Pt(before); st.paragraph_format.space_after=Pt(after)
    st.paragraph_format.keep_with_next=True
    st.paragraph_format.line_spacing=1.1
if 'Legenda Gaia' not in styles:
    st=styles.add_style('Legenda Gaia', WD_STYLE_TYPE.PARAGRAPH)
    st.font.name='Arial'; st.font.size=Pt(9); st.font.color.rgb=RGBColor(84,100,115)
    st.paragraph_format.space_after=Pt(10); st.paragraph_format.space_before=Pt(4)
    st.paragraph_format.alignment=WD_ALIGN_PARAGRAPH.CENTER
if 'Codigo Gaia' not in styles:
    st=styles.add_style('Codigo Gaia', WD_STYLE_TYPE.PARAGRAPH)
    st.font.name='Consolas'; st.font.size=Pt(9)
    st.paragraph_format.space_after=Pt(1); st.paragraph_format.space_before=Pt(1)
    st.paragraph_format.line_spacing=1.0

# cabecalho e rodape
h=sec.header.paragraphs[0]; h.text='GRUPO GAIA  |  PSE EM AÇÃO  |  AEP 2026'
h.style=styles['Normal']; h.alignment=WD_ALIGN_PARAGRAPH.RIGHT
for r in h.runs: r.font.name='Arial'; r.font.size=Pt(8); r.font.color.rgb=RGBColor.from_string(GRAY)
f=sec.footer.paragraphs[0]; f.alignment=WD_ALIGN_PARAGRAPH.CENTER
r=f.add_run('Grupo Gaia  •  2ª entrega da AEP  |  Página '); r.font.size=Pt(8);r.font.name='Arial'
fld=OxmlElement('w:fldSimple'); fld.set(qn('w:instr'),'PAGE'); f._p.append(fld)

def p(txt='', boldstart=None, style=None):
    para=doc.add_paragraph(style=style)
    if boldstart and txt.startswith(boldstart):
        para.add_run(boldstart).bold=True
        para.add_run(txt[len(boldstart):])
    else: para.add_run(txt)
    return para

def h1(t): doc.add_heading(t,level=1)
def h2(t): doc.add_heading(t,level=2)
def h3(t): doc.add_heading(t,level=3)
def pg(): doc.add_page_break()
def bullet(t):
    q=doc.add_paragraph(t,style='List Bullet');q.paragraph_format.left_indent=Cm(.6);q.paragraph_format.space_after=Pt(3)
    return q

def table(headers, rows, sizes=None):
    tab=doc.add_table(rows=1,cols=len(headers))
    tab.alignment=WD_TABLE_ALIGNMENT.CENTER
    tab.style='Table Grid'
    for j,x in enumerate(headers): tab.rows[0].cells[j].text=str(x)
    for row in rows:
        cells=tab.add_row().cells
        for j,x in enumerate(row): cells[j].text=str(x)
    for i,row in enumerate(tab.rows):
        row.height=None
        for j,cell in enumerate(row.cells):
            cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if sizes: cell.width=Cm(sizes[j])
            if i==0:
                tcPr=cell._tc.get_or_add_tcPr(); shading=OxmlElement('w:shd'); shading.set(qn('w:fill'),NAVY);tcPr.append(shading)
            for para in cell.paragraphs:
                para.paragraph_format.space_after=Pt(2)
                para.paragraph_format.space_before=Pt(2)
                para.paragraph_format.line_spacing=1.07
                para.alignment=WD_ALIGN_PARAGRAPH.LEFT
                for run in para.runs:
                    run.font.name='Arial';run.font.size=Pt(8.5)
                    if i==0: run.font.bold=True;run.font.color.rgb=RGBColor(255,255,255)
    doc.add_paragraph('').paragraph_format.space_after=Pt(0)
    return tab

def imagem(path, legenda, largura=14.7):
    doc.add_picture(str(BASE/path),width=Cm(largura))
    q=doc.paragraphs[-1];q.alignment=WD_ALIGN_PARAGRAPH.CENTER;q.paragraph_format.space_after=Pt(0)
    doc.add_paragraph(legenda,style='Legenda Gaia')

def codigo(*linhas):
    for line in linhas:
        q=doc.add_paragraph(line,style='Codigo Gaia')
        shading=OxmlElement('w:shd');shading.set(qn('w:fill'),'F0F4F7');q._p.get_or_add_pPr().append(shading)

def uc(cod,nome,objetivo,pre,principal,alternativo,pos):
    h3(f'{cod} — {nome}')
    table(['Campo','Descrição'],[
        ('Ator','Profissional da educação ou saúde responsável pelas ações coletivas.'),
        ('Objetivo',objetivo),('Pré-condições',pre),('Fluxo principal',principal),
        ('Fluxos alternativos',alternativo),('Pós-condições',pos)], [3.2,12.8])

# capa
for _ in range(3): doc.add_paragraph('')
q=doc.add_paragraph('UNICESUMAR',style='Title');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
q=doc.add_paragraph('AEP • LINGUAGEM C, ENGENHARIA DE SOFTWARE E PRODUÇÃO TEXTUAL');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
q.runs[0].font.name='Arial';q.runs[0].font.size=Pt(10)
for _ in range(3): doc.add_paragraph('')
q=doc.add_paragraph('GRUPO GAIA');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
for r in q.runs:r.font.bold=True;r.font.size=Pt(16)
q=doc.add_paragraph('PSE EM AÇÃO');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
for r in q.runs:r.font.name='Arial';r.font.bold=True;r.font.size=Pt(23);r.font.color.rgb=RGBColor.from_string(NAVY)
q=doc.add_paragraph('Sistema de Planejamento e Acompanhamento de Ações do Programa Saúde na Escola');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
for r in q.runs:r.font.size=Pt(13)
for _ in range(2): doc.add_paragraph('')
q=doc.add_paragraph('RELATÓRIO FINAL  |  2ª ENTREGA: IMPLEMENTAÇÃO E APRESENTAÇÃO');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
for r in q.runs:r.font.bold=True;r.font.name='Arial';r.font.size=Pt(11)
for _ in range(2): doc.add_paragraph('')
q=p('Integrantes: [INSERIR NOMES DOS INTEGRANTES]')
q.alignment=WD_ALIGN_PARAGRAPH.CENTER
q=p('Curso / turma: [CONFERIR DADOS COM O GRUPO]')
q.alignment=WD_ALIGN_PARAGRAPH.CENTER
for _ in range(3): doc.add_paragraph('')
q=p('Maringá – PR | 2026');q.alignment=WD_ALIGN_PARAGRAPH.CENTER
pg()

h1('RESUMO')
p('Este relatório apresenta a conclusão técnica da segunda etapa da Atividade de Estudo Programada (AEP) do Grupo Gaia, intitulada “PSE em Ação”. O trabalho consiste em uma aplicação de terminal, desenvolvida em C99, destinada à organização de ações coletivas do Programa Saúde na Escola. A versão final implementa cadastro, listagem, pesquisa, atualização de situação, resumo diário e resumo geral, com validações de campos, data, códigos e limite de armazenamento. A modelagem de casos de uso, os fluxogramas atualizados, o manual do usuário e as evidências de execução e teste integram a documentação. O sistema utiliza registros fictícios e dados coletivos, mantidos temporariamente em memória. Os testes automatizados verificaram as principais operações e situações de erro. O vídeo, a publicação no GitHub e a identificação dos integrantes dependem da etapa de submissão realizada pelo próprio grupo.')
p('Palavras-chave: Programa Saúde na Escola; linguagem C; estrutura de dados; caso de uso; validação; AEP.')
h1('SUMÁRIO DO DOCUMENTO')
for s in ['1. Contextualização e objetivos','2. Requisitos e escopo','3. Implementação e decisões técnicas','4. Engenharia de software: casos de uso','5. Fluxogramas e rastreabilidade','6. Plano de testes e evidências','7. Manual de uso e execução','8. Resultados, limitações e melhorias','9. Apresentação em vídeo e entregáveis','10. Referências e fontes do projeto']:
    q=p(s);q.paragraph_format.space_after=Pt(2)
pg()

h1('1. CONTEXTUALIZAÇÃO E OBJETIVOS')
p('O Programa Saúde na Escola (PSE) integra ações de promoção da saúde no ambiente educacional. A primeira etapa do Grupo Gaia identificou a necessidade de registrar e acompanhar atividades coletivas, evitando depender de anotações dispersas. O projeto não substitui sistemas oficiais de saúde ou educação e não realiza diagnóstico, triagem, prescrição ou prontuários individuais.')
p('Questão norteadora: como uma aplicação em C, com funcionamento em terminal, pode auxiliar profissionais da educação e da saúde na organização de ações coletivas, com informações compreensíveis e respeito à privacidade dos estudantes?')
h2('1.1 Objetivo geral')
p('Implementar, documentar e demonstrar um sistema acadêmico funcional para cadastro, consulta, acompanhamento e resumo de ações coletivas do PSE, utilizando linguagem C e conceitos de programação introdutória.')
h2('1.2 Objetivos específicos')
for x in ['Cadastrar ações com escola, turma, período, tema, data, público-alvo, responsável, quantidade e situação.', 'Listar e pesquisar ações por diferentes critérios.', 'Atualizar a situação e o número de participantes efetivos.', 'Obter resumos por data e gerais, incluindo percentual de participação.', 'Validar entradas e lidar com situações de erro sem interromper o sistema.', 'Produzir código testável, casos de uso, fluxogramas, manual e evidências.']:
    bullet(x)

h1('2. REQUISITOS E ESCOPO')
h2('2.1 Requisitos funcionais consolidados')
table(['ID','Requisito implementado','Evidência'],[
('RF01','Cadastrar ação com código, escola, turma, período, tema, data, público, responsável, quantidade prevista e situação inicial.','Opção 1; estrutura Acao.'),
('RF02','Listar todas as ações cadastradas.','Opção 2; exibirAcao.'),
('RF03','Pesquisar por código, escola, tema, professor/responsável e turma.','Opção 3; pesquisarAcoes.'),
('RF04','Atualizar situação: Planejada, Realizada ou Cancelada.','Opção 4.'),
('RF05','Registrar participantes efetivos nas ações realizadas.','Cadastro e atualização.'),
('RF06','Gerar resumo por data e resumo geral, incluindo percentual de participação.','Opção 5; data ou G.'),
('RF07','Validar obrigatórios, código, data, quantidade, opção e capacidade.','Funções de entrada e validação.'),
])
h2('2.2 Requisitos não funcionais')
table(['ID','Descrição','Aplicação'],[
('RNF01','C99 e compilação em terminal.','GCC com flags de aviso.'),
('RNF02','Interface textual com mensagens claras.','Menu de 1 a 6 e retorno às operações.'),
('RNF03','Utilização acadêmica, com dados fictícios e coletivos.','Aviso no cadastro e no README.'),
('RNF04','Armazenamento temporário.','Vetor estático de até 100 ações.'),
('RNF05','Código organizado em funções.','Entrada, apoio, operações e main.'),
])
h2('2.3 Limites e regras de negócio')
p('O vetor possui capacidade padrão de 100 registros. Cada código é inteiro positivo e único. A quantidade prevista deve ser no mínimo 1 e a efetiva pode ser 0. Datas devem existir no calendário entre os anos 2000 e 2100. A busca textual aceita trechos de texto e diferenças de caixa ASCII. Dados individuais de estudantes não fazem parte do uso permitido, embora a interface não consiga identificar automaticamente dados sensíveis digitados em texto livre.')

h1('3. IMPLEMENTAÇÃO E DECISÕES TÉCNICAS')
h2('3.1 Estrutura de dados e funções')
p('A implementação utiliza struct Acao e um vetor estático acoes[MAX_ACOES]. O contador totalAcoes registra quantas posições foram preenchidas e impede escrita fora do limite. Ações armazenam código, escola, turma, período, tema, data prevista, público-alvo, responsável, quantidade prevista, quantidade efetiva e situação.')
for x in ['Entrada segura: lerLinha utiliza fgets; lerInteiro converte com strtol e detecta valores inválidos.', 'Validação de data: dataValida verifica DD/MM/AAAA, mês, dias reais, anos bissextos e intervalo permitido.', 'Cadastro e localização: buscarIndicePorCodigo evita duplicidade e identifica registros inexistentes.', 'Pesquisa: contemTexto realiza correspondência de trechos de texto.', 'Controle de situação: atualizarSituacao modifica registro apenas depois da validação; valores efetivos antigos são zerados se a ação deixa de estar Realizada.', 'Resumos: imprimirResumo usa a data como filtro opcional e calcula contagens e participação com acumuladores long long.']:
    bullet(x)
h2('3.2 Lógica do percentual de participação')
p('Percentual de participação = (participantes efetivos das ações realizadas ÷ participantes previstos das ações realizadas) × 100. A previsão de ações planejadas ou canceladas não entra nesse denominador. Por exemplo, uma ação realizada com 18 participantes efetivos e previsão de 20 gera 90,0%. Quando não existem ações realizadas, o sistema informa que o percentual não é calculável.')
h2('3.3 Complementos e correções na passagem da 1ª para a 2ª etapa')
table(['Situação anterior','Ajuste na versão final','Justificativa'],[
('Código C não possuía turma/período.','Campos incluídos em struct Acao e nas telas.','Alinhamento ao fluxograma detalhado.'),
('Situação inicial fixa como Planejada.','Seleção de Planejada, Realizada ou Cancelada.','Alinhamento ao pseudocódigo do grupo.'),
('Pesquisa apenas código, escola e tema.','Incluídos responsável e turma.','Coerência com os fluxogramas da opção 3.'),
('Resumo apenas geral.','Resumo por dia e geral na opção 5.','Preserva o recurso pronto e cumpre o fluxograma.'),
('Saída pela opção 0.','Saída pela opção 6, com confirmação.','Padronização do menu planejado.'),
('Validações parciais de campos.','Datas reais, opções, textos e limite validados.','Redução de erros de entrada.'),
])
p('O resumo geral foi preservado sem acrescentar uma nova opção ao menu: ao acessar a opção 5, o usuário informa a data ou digita G. Assim, a operação diária planejada permanece acessível e a funcionalidade anterior não é perdida.')

h1('4. ENGENHARIA DE SOFTWARE: CASOS DE USO')
h2('4.1 Atores e diagrama')
p('Ator primário: profissional da educação ou da saúde responsável pelo planejamento e acompanhamento das ações do PSE. O diagrama representa o uso do sistema em terminal e os processos de validação de entradas e registro de participantes efetivos.')
imagem('diagramas/casos_de_uso.png','Figura 1 – Diagrama de casos de uso da versão implementada. Fonte: elaboração do Grupo Gaia, 2026.',14.7)
pg()
h2('4.2 Descrição dos casos de uso principais')
uc('UC01','Cadastrar ação',
   'Registrar uma atividade coletiva do PSE.',
   'Programa aberto; ainda há espaço no vetor.',
   'Selecionar opção 1; informar código único e positivo; preencher escola, turma, período, tema, data, público, responsável, previsão e situação; informar efetivos se realizada; confirmar inclusão.',
   'Código repetido ou vetor cheio: exibir erro e retornar. Campos vazios, datas, quantidades ou escolhas inválidas: solicitar correção.',
   'Novo registro gravado em memória, contador incrementado e confirmação apresentada.')
uc('UC02','Listar ações',
   'Consultar os registros existentes.',
   'Programa aberto.',
   'Selecionar opção 2; percorrer o vetor; mostrar informações completas e total de registros.',
   'Vetor vazio: informar que não há ações cadastradas.',
   'Nenhum registro alterado.')
uc('UC03','Pesquisar ações',
   'Localizar ação por código, escola, tema, responsável ou turma.',
   'Ao menos uma ação cadastrada.',
   'Selecionar opção 3; escolher filtro; informar código ou termo; percorrer registros e mostrar resultados.',
   'Filtro inválido: repetir escolha. Código ou termo sem resultados: mostrar aviso.',
   'Registros correspondentes apresentados; dados preservados.')
pg()
uc('UC04','Atualizar situação',
   'Acompanhar andamento da ação e seus participantes.',
   'Registro existente identificado pelo código.',
   'Selecionar opção 4; informar código; visualizar ação; escolher Planejada, Realizada ou Cancelada; se Realizada, informar quantidade efetiva; confirmar.',
   'Código inexistente: avisar e retornar. Escolha ou quantidade inválida: solicitar novo valor.',
   'Situação atualizada; quantidade efetiva registrada na realizada ou zerada nos demais estados.')
uc('UC05','Gerar resumo por dia',
   'Apresentar resultados referentes a uma data prevista.',
   'Programa aberto.',
   'Selecionar opção 5; informar data válida; filtrar registros pela data; contabilizar situações e participantes; calcular taxa nas ações realizadas.',
   'Data inválida: exibir erro. Data sem ações: comunicar ausência de registros.',
   'Resumo diário exibido sem alterar os registros.')
uc('UC06','Gerar resumo geral',
   'Manter consulta consolidada do código C anterior.',
   'Programa aberto.',
   'Selecionar opção 5; digitar G; somar resultados de todas as datas e apresentar percentual.',
   'Sem ações: informar ausência de registros; sem realizadas: percentual não calculável.',
   'Resumo geral exibido sem alterar registros.')
pg()
uc('UC07','Encerrar sistema',
   'Finalizar a execução do programa.',
   'Programa em execução.',
   'Selecionar opção 6; confirmar com 1; apresentar despedida e finalizar.',
   'Confirmar com 2: voltar ao menu. Opção inválida: solicitar nova escolha.',
   'Aplicação encerrada e dados temporários descartados.')

h1('5. FLUXOGRAMAS E RASTREABILIDADE')
p('A primeira entrega apresentava um fluxograma geral e um cadastro detalhado. As figuras seguintes representam a versão efetivamente implementada e registram as mudanças no resumo, na confirmação de saída e nas validações feitas durante a entrada.')
imagem('diagramas/fluxo_menu.png','Figura 2 – Fluxo geral: menu, execução das operações, retorno e saída. Fonte: elaboração do Grupo Gaia, 2026.',14.7)
pg()
imagem('diagramas/fluxo_cadastro.png','Figura 3 – Fluxo atualizado da operação Cadastrar Ação. Fonte: elaboração do Grupo Gaia, 2026.',12.6)
p('Rastreabilidade: RF01 e RF07 correspondem ao fluxo de cadastro; RF02 à listagem; RF03 à pesquisa; RF04 e RF05 à atualização de situação; RF06 aos resumos. Os casos de uso UC01 a UC07 descrevem os mesmos caminhos que o programa executa.')

h1('6. PLANO DE TESTES E EVIDÊNCIAS')
h2('6.1 Ambiente, método e resultado')
p('O programa foi compilado em ambiente Linux com GCC, utilizando o padrão C99 e as opções -Wall -Wextra -Werror -pedantic, sem erros nem avisos. Testes automatizados enviaram entradas ao executável, analisaram suas saídas e verificaram situações de sucesso e falha. A rotina está em testes/testar_sistema.py. Foram aprovadas 16 verificações de comportamento, além da compilação. Os dados dos testes são fictícios.')
h2('6.2 Matriz de testes executados')
table(['Teste','Entrada / situação','Resultado observado'],[
('T01','Iniciar sem registros; listar, pesquisar e atualizar.','Mensagens de sistema vazio, sem falha.'),
('T02','Sem dados; consultar data e confirmar/recusar saída.','Aviso de ausência; retorno e saída corretos.'),
('T03','Criar ações Planejada e Realizada.','Dois registros cadastrados.'),
('T04','Pesquisar por código, escola, tema, responsável e turma.','Filtros identificaram ações.'),
('T05','Tentar cadastrar código já utilizado.','Duplicação impedida.'),
('T06','Resumo por data: 30 planejados e 20 previstos/18 efetivos realizados.','1 planejada, 1 realizada; taxa 90,0%.'),
('T07','Atualizar para Realizada com 28 efetivos.','2 realizadas; taxa 92,0%.'),
('T08','Digitar G na opção 5.','Resumo geral apresentado.'),
('T09','Alterar ação Realizada para Cancelada.','Efetivos antigos não são mantidos.'),
('T10','Digitar texto e número fora do menu.','Opção inválida tratada.'),
('T11','Informar código 0 e previsão negativa.','Reentrada e rejeição de valores.'),
('T12','Deixar campos vazios e escolher período incorreto.','Reentrada obrigatória.'),
('T13','31/02/2026, 29/02/2025 e 29/02/2028.','Datas impossíveis rejeitadas; bissexto aceito.'),
('T14','Informar situação inexistente.','Escolha recusada e solicitada novamente.'),
('T15','Compilar com MAX_ACOES=2 e cadastrar 3 ações.','Terceiro cadastro bloqueado.'),
('T16','Cadastrar 100 ações e tentar a 101ª.','Limite padrão respeitado.'),
])
h2('6.3 Capturas de tela da execução')
p('As imagens a seguir foram produzidas a partir da saída de uma execução real do programa em pseudo-terminal. Os registros de teste utilizam escolas, responsáveis e quantidades fictícias. As capturas de todas as operações ficam disponíveis no diretório imagens do pacote.')
imagem('imagens/01_menu.png','Figura 4 – Menu principal exibido após iniciar o programa.',14.7)
imagem('imagens/02_cadastro.png','Figura 5 – Preenchimento dos campos no cadastro (recorte da execução).',14.5)
pg()
imagem('imagens/03_listagem.png','Figura 6 – Listagem dos registros cadastrados, com todos os campos.',12.8)
pg()
imagem('imagens/07_pesquisa.png','Figura 7 – Pesquisa por professor/responsável.',14.3)
imagem('imagens/08_atualizacao.png','Figura 8 – Atualização de situação, identificando a ação pelo código.',14.3)
pg()
imagem('imagens/04_resumo_dia.png','Figura 9 – Resumo por dia com situações e percentual de participação.',14.7)
imagem('imagens/06_validacao.png','Figura 10 – Bloqueio de código duplicado.',14.7)

h1('7. MANUAL DE USO E EXECUÇÃO')
h2('7.1 Pré-requisitos e compilação')
p('É necessário um compilador C compatível com C99, como GCC. O programa não requer instalação de bibliotecas extras. Abra o terminal na pasta do arquivo pse_em_acao.c e execute:')
codigo('gcc -std=c99 -Wall -Wextra -pedantic -o pse_em_acao pse_em_acao.c', './pse_em_acao')
p('No Windows com MinGW/MSYS2, utilizar -o pse_em_acao.exe e executar pse_em_acao.exe (ou .\\pse_em_acao.exe no PowerShell).')
h2('7.2 Passo a passo')
for x in ['Ao abrir, selecione 1 para cadastrar. Informe um código novo (exemplo: 101).', 'Preencha Escola Municipal Aurora, turma 5A, período 1, tema Saúde bucal, data 15/11/2026, público 5º ano, responsável Prof. Ana e 30 participantes previstos. Escolha situação 1, Planejada.', 'Utilize a opção 2 para conferir a listagem; a opção 3 para localizar registros pelos cinco critérios.', 'Selecione 4, informe o código 101 e escolha 2 para marcá-la como Realizada. Digite a quantidade efetiva.', 'Selecione 5, digite 15/11/2026 para consultar o dia; digite G para visualizar todas as datas.', 'Para sair, escolha 6 e confirme com 1. Para cancelar a saída, escolha 2.']:
    bullet(x)
h2('7.3 Respostas esperadas e erros comuns')
p('O sistema confirma o cadastro por código e situação. Se o código já existir, a operação é cancelada. Se o campo for obrigatório ou a entrada for inválida, o programa solicita nova informação. Quando uma busca não encontra resultado, exibe aviso. Caso sejam atingidos 100 registros, um novo cadastro não será permitido até reiniciar o processo com outro limite de compilação.')
p('Importante: os registros ficam em memória e não são gravados em arquivo. Fechar o programa apaga a sessão. O usuário não deve cadastrar dados pessoais de estudantes.')

h1('8. RESULTADOS, LIMITAÇÕES E POSSÍVEIS MELHORIAS')
h2('8.1 Resultados obtidos')
p('A solução implementada executa as operações previstas no trabalho do Grupo Gaia. A versão final cobre o cadastro completo, a listagem, as pesquisas, a atualização das situações e o cálculo de resumos por data, mantendo ainda o resumo geral do protótipo anterior. O conjunto automatizado de testes confirmou as entradas principais e a proteção contra erros previstos no enunciado.')
h2('8.2 Limitações')
for x in ['Armazenamento somente em memória: os registros deixam de existir após o encerramento.', 'Limite de 100 ações por execução (configurável na compilação, mas sem persistência).', 'Interface textual, sem interface gráfica nem perfis de usuário.', 'Não realiza normalização Unicode completa na pesquisa por texto.', 'Sem integração com sistemas oficiais do PSE e sem importação/exportação de informações.', 'A restrição ao uso de dados fictícios é uma regra operacional; campos de texto não detectam automaticamente informações pessoais.']:
    bullet(x)
h2('8.3 Propostas de evolução')
p('Como melhorias futuras, recomenda-se armazenamento em arquivo ou banco de dados, exportação de relatórios, filtros por período e situação, normalização adequada de textos com acentos, testes em diferentes plataformas e eventual autenticação. Esses recursos não são necessários para os objetivos introdutórios desta AEP.')
h2('8.4 Considerações finais')
p('O desenvolvimento do PSE em Ação permitiu aplicar funções, estruturas condicionais, laços de repetição, vetores, struct, validação de entradas e organização modular em um problema prático. A ligação entre requisitos, fluxogramas, casos de uso e testes fortalece a consistência do projeto. O resultado corresponde a um protótipo acadêmico funcional, apropriado para demonstração de conceitos básicos de programação e engenharia de software, dentro das limitações declaradas.')

h1('9. APRESENTAÇÃO EM VÍDEO E ENTREGÁVEIS')
h2('9.1 Plano de apresentação (até 7 minutos)')
table(['Tempo','Conteúdo','Demonstração / fala'],[
('0:00–0:40','Problema e objetivo','Apresentar PSE, Grupo Gaia e proposta.'),
('0:40–1:20','Requisitos e casos de uso','Mostrar diagrama e funções.'),
('1:20–2:30','Cadastro e validação','Compilar e cadastrar; duplicar código.'),
('2:30–3:40','Listagem, pesquisa e atualização','Executar 2, 3 e 4 com dados fictícios.'),
('3:40–4:30','Resumos','Exibir resumo por data e geral.'),
('4:30–5:40','Explicação do código','Struct, funções, validação e fluxogramas.'),
('5:40–6:15','Testes','Mostrar resultados e erros previstos.'),
('6:15–6:40','Síntese e limitações','Resultados, aprendizados e finalização.'),
])
p('O roteiro completo, com distribuição sugerida de falas, está disponível no arquivo documentacao/roteiro_video.md. A gravação precisa ser feita pelos integrantes e mostrará o executável em funcionamento.')
h2('9.2 Links a preencher pelo grupo antes da entrega')
p('Repositório GitHub (com código e README): [COLAR LINK REAL APÓS PUBLICAR]')
p('Vídeo de apresentação (acesso liberado): [COLAR LINK REAL APÓS GRAVAR]')
p('Integrantes e identificação acadêmica: [CONFERIR E PREENCHER NA CAPA]')
h2('9.3 Relação dos arquivos preparados')
for x in ['Código-fonte C99, pronto para compilação.', 'README com instruções de uso e compilação.', 'Documento final em Word e PDF, com casos de uso, testes, manual e conclusões.', 'Diagramas revisados e capturas de execução real.', 'Script de testes com resultados e transcrições.', 'Roteiro para o vídeo da equipe, limitado a 7 minutos.']:
    bullet(x)
p('Pendências externas à preparação dos arquivos: publicação no GitHub, gravação do vídeo com os integrantes, inclusão dos links verdadeiros e validação dos dados de capa. Esses itens não foram declarados como concluídos.')

h1('10. REFERÊNCIAS E FONTES DO PROJETO')
p('GRUPO GAIA. PSE em Ação: primeira etapa da AEP, com objetivos, requisitos, fluxogramas, pseudocódigo e planejamento de sprints. Material de trabalho fornecido pelos integrantes, 2026.')
p('GRUPO GAIA. Arquivo pse_em_acao.c e README.md: protótipo inicial em linguagem C e instruções. Materiais de desenvolvimento fornecidos pela equipe, 2026.')
p('UNICESUMAR. 2ª entrega – Implementação e apresentação. Enunciado acadêmico disponibilizado à equipe em imagem, 2026.')
p('O documento da primeira etapa contém fundamentação sobre o PSE e cita o Decreto nº 6.286/2007. As referências externas daquele texto devem permanecer na bibliografia da versão integral caso o grupo opte por anexar a primeira etapa como documento adicional.')

OUT.parent.mkdir(exist_ok=True,parents=True)
doc.save(str(OUT))
print('CRIADO',OUT)
