# Roteiro de apresentação | Grupo Gaia | PSE em Ação

**Duração planejada:** 6min40s. **Duração máxima exigida:** 7 minutos.

A apresentação precisa ser gravada com os integrantes do grupo. Os papéis abaixo são sugestões para dividir a fala; substituir pelos nomes reais. Gravar a tela com o código compilando e o programa em funcionamento.

| Tempo | Responsável sugerido | Fala/demonstração |
|---|---|---|
| 0:00–0:40 | Integrante 1 | Apresentar o Grupo Gaia, a proposta da AEP e o problema: organizar ações coletivas do Programa Saúde na Escola sem dados individuais de alunos. |
| 0:40–1:20 | Integrante 1 | Mostrar objetivo e requisitos: cadastrar, listar, pesquisar, atualizar situação, resumo por dia e validações. Mostrar rapidamente o diagrama de casos de uso. |
| 1:20–2:30 | Integrante 2 | Mostrar o programa compilando com GCC, abrir o menu e cadastrar ação com escola, turma, período, tema, data, público e responsável. Mostrar código repetido como caso de erro. |
| 2:30–3:40 | Integrante 2 | Listar, pesquisar por tema ou responsável, atualizar situação para Realizada e informar participantes efetivos. |
| 3:40–4:30 | Integrante 3 | Mostrar resumo por dia e opção G de resumo geral. Explicar rapidamente o percentual de participação. |
| 4:30–5:40 | Integrante 3 | Abrir `pse_em_acao.c`: apontar `struct Acao`, vetor `acoes`, funções de validação (`dataValida`, `buscarIndicePorCodigo`), `switch` do menu e laços. Relacionar com os dois fluxogramas atualizados. |
| 5:40–6:15 | Integrante 1 | Apresentar os testes: 16 verificações de comportamento aprovadas, casos de data inválida, código duplicado, registro inexistente e limite de 100 ações. |
| 6:15–6:40 | Integrantes | Sintetizar resultados e limitações: dados só em memória, uso didático, sem registro de alunos. Agradecer e encerrar. |

## Sequência prática para gravar

1. Abrir o terminal na pasta do projeto e executar o comando de compilação do README.
2. Executar o programa, cadastrar duas ações com códigos diferentes e a mesma data (uma planejada e outra realizada).
3. Testar duplicidade do código, listar, pesquisar e atualizar uma ação.
4. Gerar resumo com a data cadastrada e depois com `G`.
5. Mostrar rapidamente o código e os diagramas e encerrar pelo menu 6.

## Antes de enviar

- Conferir que o vídeo tem até 7 minutos, áudio audível e participação dos integrantes.
- Garantir que os números no vídeo são de dados **fictícios**.
- Abrir o link do vídeo em janela anônima para verificar permissão de acesso.
- Colar o link do vídeo e do GitHub na versão final do relatório antes da entrega.
