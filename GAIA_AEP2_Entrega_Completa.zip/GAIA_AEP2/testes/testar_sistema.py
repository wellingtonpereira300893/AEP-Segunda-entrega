#!/usr/bin/env python3
"""Testes automatizados de terminal do PSE em Acao, Grupo Gaia.
Executa a versao C99, verifica mensagens e valida o limite MAX_ACOES.
Nao usa dependencias externas.
"""
from pathlib import Path
import subprocess
import tempfile
import sys
import re

BASE = Path(__file__).resolve().parent.parent
FONTE = BASE / 'pse_em_acao.c'
PASTA = BASE / 'testes'


def executar(binario: Path, entradas: str) -> str:
    proc = subprocess.run([str(binario)], input=entradas, text=True,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=15, encoding='utf-8', errors='replace')
    if proc.returncode != 0:
        raise AssertionError(f'Processo retornou {proc.returncode}: {proc.stderr}')
    return proc.stdout


def verificar(nome: str, condicao: bool, detalhe='') -> None:
    if not condicao:
        raise AssertionError(f'FALHOU: {nome}. {detalhe}')
    print(f'APROVADO: {nome}')


def cadastrar(codigo, escola, turma, periodo, tema, data, publico, responsavel, prevista, situacao=1, efetiva=0):
    linhas = ['1', str(codigo), escola, turma, str(periodo), tema,
              data, publico, responsavel, str(prevista), str(situacao)]
    if situacao == 2:
        linhas.append(str(efetiva))
    return '\n'.join(linhas) + '\n'


def main():
    with tempfile.TemporaryDirectory() as pasta:
        exe = Path(pasta) / 'pse_testado'
        comando = ['gcc', '-std=c99', '-Wall', '-Wextra', '-Werror', '-pedantic',
                   '-o', str(exe), str(FONTE)]
        subprocess.run(comando, check=True, capture_output=True, text=True)
        print('APROVADO: compilacao GCC C99 sem avisos')

        entrada = '2\n3\n4\n5\n15/11/2026\n6\n2\n6\n1\n'
        vazio = executar(exe, entrada)
        verificar('sistema vazio e sem travamentos', 'Nenhuma acao cadastrada.' in vazio and
                  'Nenhuma acao cadastrada para pesquisar.' in vazio and
                  'Nenhuma acao cadastrada para atualizar.' in vazio)
        verificar('consulta sem dados e saida confirmada',
                  'Nenhuma acao encontrada para esta consulta.' in vazio and
                  'Retornando ao menu principal' in vazio and
                  'Sistema encerrado' in vazio)

        entradas = ''
        entradas += cadastrar(10,'Escola Municipal Sol','5A',1,'Saude bucal',
                             '15/11/2026','Ensino Fundamental','Prof. Ana',30,1)
        entradas += cadastrar(20,'Escola Municipal Sol','5B',2,'Alimentacao saudavel',
                             '15/11/2026','Ensino Fundamental','Prof. Bruno',20,2,18)
        entradas += '2\n'                     # listar
        entradas += '3\n1\n10\n'            # buscar codigo
        entradas += '3\n2\nsol\n'           # buscar escola por trecho
        entradas += '3\n3\nalimentacao\n'   # buscar tema
        entradas += '3\n4\nbruno\n'         # buscar responsavel
        entradas += '3\n5\n5a\n'            # buscar turma
        entradas += '3\n1\n999\n'          # registro inexistente
        entradas += '5\n15/11/2026\n'       # resumo dia (1 plan.,1 realiz.)
        entradas += '4\n10\n2\n28\n'       # update 10 -> realizada 28
        entradas += '5\n15/11/2026\n'       # resumo dia (2 realiz.)
        entradas += '5\nG\n'                # resumo geral
        entradas += '4\n20\n3\n'            # cancela 20, limpa qtd
        entradas += '2\n'                     # lista confere cancelamento
        entradas += '1\n10\n'               # codigo duplicado
        entradas += '6\n1\n'
        saida = executar(exe, entradas)
        (PASTA / 'execucao_exemplo.txt').write_text(saida, encoding='utf-8')
        verificar('cadastros de estados inicial planejada e realizada',
                  saida.count('Acao cadastrada com sucesso!') == 2)
        verificar('todos os 5 filtros de pesquisa',
                  saida.count('Total encontrado:') == 4 and
                  'Nenhuma acao encontrada com esse codigo.' in saida)
        verificar('cadastro duplicado impedido', 'Erro: codigo ja cadastrado.' in saida)
        verificar('resumo diario filtra corretamente os 2 registros',
                  'Planejadas: 1 | Realizadas: 1 | Canceladas: 0' in saida and
                  'Participacao nas acoes realizadas: 90.0%' in saida)
        verificar('atualizacao altera resumo e participantes',
                  'Planejadas: 0 | Realizadas: 2 | Canceladas: 0' in saida and
                  'Participacao nas acoes realizadas: 92.0%' in saida)
        verificar('resumo geral continua disponivel', '--- RESUMO GERAL ---' in saida)
        verificar('atualizacao para cancelada zera efetivos',
                  re.search(r'Codigo: 20.*?Quantidade efetiva: ainda nao aplicavel.*?Situacao: Cancelada',
                            saida, re.S) is not None)

        invalidas = 'a\n7\n'
        invalidas += '1\n0\n30\n'           # codigo nao positivo
        invalidas += '\nEscola Primavera\n' # campo obrigatorio
        invalidas += '\nTurma A\n'        # campo obrigatorio
        invalidas += '9\n3\n'             # periodo invalido, corrige Noite
        invalidas += '\nSaude mental\n'  # tema obrigatorio
        invalidas += '31/02/2026\n29/02/2025\n29/02/2028\n'
        invalidas += '7A\nProf. Carla\n-2\n12\n9\n3\n'
        invalidas += '5\n31/02/2026\n'
        invalidas += '5\n29/02/2028\n'
        invalidas += '6\n1\n'
        erros = executar(exe, invalidas)
        (PASTA / 'execucao_validacoes.txt').write_text(erros, encoding='utf-8')
        verificar('menu numerico invalido tratado',
                  'Erro: opcao invalida.' in erros)
        verificar('codigo nao positivo e quantidade negativa rejeitados',
                  'maior ou igual a 1' in erros and 'Acao cadastrada com sucesso! Codigo 30' in erros)
        verificar('campos obrigatorios e periodo invalido tratados',
                  erros.count('campo obrigatorio') >= 3 and 'escolha uma opcao de 1 a 3' in erros)
        verificar('validacao de data real e bissexta',
                  erros.count('Erro: data invalida.') >= 3 and
                  'Data consultada: 29/02/2028' in erros)
        verificar('situacao invalida rejeitada', erros.count('escolha uma opcao de 1 a 3') >= 2)

        bin_lim = Path(pasta) / 'pse_lim2'
        subprocess.run(['gcc','-std=c99','-Wall','-Wextra','-Werror',
                        '-DMAX_ACOES=2',str(FONTE),'-o',str(bin_lim)],
                       check=True, capture_output=True, text=True)
        lotacao = (cadastrar(1,'Escola A','6A',1,'Tema A','10/11/2026','6o ano','Ana',10)
                  + cadastrar(2,'Escola B','6B',2,'Tema B','11/11/2026','6o ano','Bia',20)
                  + '1\n6\n1\n')
        limite = executar(bin_lim, lotacao)
        verificar('limite de armazenamento protegido',
                  'limite maximo de 2 acoes atingido' in limite and
                  limite.count('Acao cadastrada com sucesso!') == 2)

        # Tambem verifica 100 cadastros com -DMAX_ACOES padrao sem dependencias.
        lotacao100 = ''.join(cadastrar(i+1,'Escola X','4A',1,'Saude',
                                     '10/11/2026','4o ano','Coord.',1)
                             for i in range(100)) + '1\n6\n1\n'
        cem = executar(exe, lotacao100)
        verificar('capacidade real de 100 registros',
                  cem.count('Acao cadastrada com sucesso!') == 100 and
                  'limite maximo de 100 acoes atingido' in cem)

        print('TOTAL: 16 verificacoes de resultado + compilacao, todas aprovadas.')
        (PASTA / 'resultado_testes.txt').write_text(
            'Testes executados pelo script testar_sistema.py\n'
            'Compilacao: gcc -std=c99 -Wall -Wextra -Werror -pedantic\n'
            'Resultado: 16 verificacoes de resultado + 1 compilacao aprovadas.\n'
            'Ambiente: execucao de terminal; dados ficticios.\n', encoding='utf-8')

if __name__ == '__main__':
    try:
        main()
    except Exception as exc:
        print(f'ERRO DE TESTE: {exc}', file=sys.stderr)
        raise
