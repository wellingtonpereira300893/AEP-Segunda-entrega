#!/usr/bin/env python3
"""Executa o aplicativo em pseudo-terminal e produz capturas da saida real."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont
import pexpect
import io, re

BASE = Path(__file__).resolve().parent.parent
exe = BASE / 'pse_em_acao'
log = io.StringIO()
c = pexpect.spawn(str(exe), encoding='utf-8', timeout=8, dimensions=(48, 118))
c.logfile_read = log

def responder(prompt, valor):
    c.expect(prompt)
    c.sendline(str(valor))

responder('Digite uma opcao:', 1)
responder('Codigo da acao:', 101)
responder('Escola:', 'Escola Municipal Aurora')
responder('Turma:', '5A')
responder('Escolha o periodo:', 1)
responder('Tema:', 'Saude bucal')
responder(r'Data prevista \(DD/MM/AAAA\):', '15/11/2026')
responder('Publico-alvo:', '5o ano')
responder('Professor/Responsavel:', 'Prof. Ana')
responder(r'Participantes previstos \(minimo 1\):', 30)
responder('Escolha a situacao:', 1)
responder('Digite uma opcao:', 1)
responder('Codigo da acao:', 102)
responder('Escola:', 'Escola Municipal Aurora')
responder('Turma:', '5B')
responder('Escolha o periodo:', 2)
responder('Tema:', 'Alimentacao saudavel')
responder(r'Data prevista \(DD/MM/AAAA\):', '15/11/2026')
responder('Publico-alvo:', '5o ano')
responder('Professor/Responsavel:', 'Prof. Bruno')
responder(r'Participantes previstos \(minimo 1\):', 20)
responder('Escolha a situacao:', 2)
responder(r'Participantes efetivos \(minimo 0\):', 18)
responder('Digite uma opcao:', 2)
responder('Digite uma opcao:', 3)
responder('Escolha o filtro:', 4)
responder('Digite o termo da pesquisa:', 'bruno')
responder('Digite uma opcao:', 5)
responder('Data ou G:', '15/11/2026')
responder('Digite uma opcao:', 5)
responder('Data ou G:', 'G')
responder('Digite uma opcao:', 4)
responder('Codigo da acao:', 101)
responder('Escolha a situacao:', 2)
responder(r'Participantes efetivos \(minimo 0\):', 28)
responder('Digite uma opcao:', 1)
responder('Codigo da acao:', 101)
responder('Digite uma opcao:', 6)
responder('Escolha:', 1)
c.expect(pexpect.EOF)
texto = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '',log.getvalue()).replace('\r\n','\n').replace('\r','')
(BASE / 'testes' / 'transcricao_terminal_real.txt').write_text(texto, encoding='utf-8')

FONTE='/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf'
FONT=ImageFont.truetype(FONTE, 22)
TITLE=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 26)

def bloco(inicio, fim=None, indice=0):
    p=-1
    for _ in range(indice+1):
        p=texto.index(inicio,p+1)
    q = texto.index(fim,p+len(inicio)) if fim else len(texto)
    return texto[p:q].strip('\n')

def imagem(nome, titulo, conteudo, linhas_max=24):
    linhas = [line.rstrip() for line in conteudo.splitlines()][:linhas_max]
    # Pseudoterminal real, sem inventar nenhuma linha de resultado.
    max_chars = max(len(line) for line in linhas) if linhas else 40
    largura = max(940, min(1650, 72 + max_chars * 14))
    altura = 118 + len(linhas)*30 + 42
    img=Image.new('RGB', (largura, altura), '#0e1826')
    d=ImageDraw.Draw(img)
    d.rounded_rectangle((22,16,largura-22,altura-17), radius=18, fill='#131e2d', outline='#2d4a66', width=2)
    d.rounded_rectangle((22,16,largura-22,82), radius=18, fill='#20374e')
    d.rectangle((22,62,largura-22,82),fill='#20374e')
    for i,col in enumerate(['#dc6565','#e4b65b','#68ba84']):
        d.ellipse((49+29*i,42,62+29*i,55), fill=col)
    d.text((170,35),titulo, font=TITLE,fill='#f0f5fb')
    for i,line in enumerate(linhas):
        color = '#9bd1ac' if ('sucesso' in line.lower() or 'realizadas:' in line.lower()) else ('#f2bd9e' if 'Erro:' in line else '#dce8f4')
        d.text((48,102+i*30),line,fill=color,font=FONT)
    img.save(BASE/'imagens'/nome)

imagem('01_menu.png','PSE em Acao | Menu principal',bloco('=============================================','Digite uma opcao:'))
imagem('02_cadastro.png','PSE em Acao | Cadastro',bloco('--- CADASTRAR ACAO ---','Acao cadastrada com sucesso!',indice=0)+'\nAcao cadastrada com sucesso!',25)
imagem('03_listagem.png','PSE em Acao | Listar acoes',bloco('--- ACOES CADASTRADAS ---','Total: 2 acao(oes).')+'Total: 2 acao(oes).',31)
imagem('04_resumo_dia.png','PSE em Acao | Resumo por dia',bloco('--- RESUMO POR DIA ---','\n============================================='),16)
imagem('05_resumo_geral.png','PSE em Acao | Resumo geral',bloco('--- RESUMO GERAL ---','\n============================================='),16)
imagem('06_validacao.png','PSE em Acao | Codigo duplicado',bloco('Erro: codigo ja cadastrado.','\n============================================='),12)
imagem('07_pesquisa.png','PSE em Acao | Pesquisa por responsavel',bloco('--- PESQUISAR ACOES ---','\n============================================='),19)
imagem('08_atualizacao.png','PSE em Acao | Atualizar situacao',bloco('--- ATUALIZAR SITUACAO ---','\n============================================='),24)
print('Capturas criadas a partir de transcricao de terminal real.')
